from email.policy import HTTP
from email.parser import Parser
from enum import IntEnum

from streaming_form_data.targets import NullTarget


c_hyphen = 45
c_cr = 13
c_lf = 10
c_min_file_body_chunk_size = 1024


class FinderState(IntEnum):
    FS_START = 0
    FS_WORKING = 1
    FS_END = 2


class ErrorGroup(IntEnum):
    Internal = 100
    Delimiting = 200
    PartHeaders = 300
    UnexpectedPart = 400


class ParserState(IntEnum):
    PS_START = 0
    PS_START_CR = 1
    PS_STARTING_BOUNDARY = 2
    PS_READING_BOUNDARY = 3
    PS_ENDING_BOUNDARY = 4
    PS_READING_HEADER = 5
    PS_ENDING_HEADER = 6
    PS_ENDED_HEADER = 7
    PS_ENDING_ALL_HEADERS = 8
    PS_READING_BODY = 9
    PS_END = 10
    PS_ERROR = 11


class Finder:
    def __init__(self, target):
        if len(target) < 1:
            raise ValueError('Empty values not allowed')
        self._target = target
        self._target_len = len(target)
        self._index = 0
        self._state = FinderState.FS_START

    @property
    def target(self):
        return self._target

    def feed(self, byte):
        if byte != self._target[self._index]:
            if self._state != FinderState.FS_START:
                self._state = FinderState.FS_START
                self._index = 0
                if byte == self._target[0]:
                    self._state = FinderState.FS_WORKING
                    self._index = 1
        else:
            self._state = FinderState.FS_WORKING
            self._index += 1
            if self._index == self._target_len:
                self._state = FinderState.FS_END

    def _reset(self):
        self._state = FinderState.FS_START
        self._index = 0

    def inactive(self):
        return self._state == FinderState.FS_START

    def active(self):
        return self._state == FinderState.FS_WORKING

    def found(self):
        return self._state == FinderState.FS_END

    def _matched_length(self):
        return self._index


class Part:
    def __init__(self, name, target):
        self.name = name
        self.targets = [target]

    def add_target(self, target):
        self.targets.append(target)

    def set_multipart_filename(self, value):
        for target in self.targets:
            target.multipart_filename = value

    def set_multipart_content_type(self, value):
        for target in self.targets:
            target.multipart_content_type = value

    def start(self):
        for target in self.targets:
            target.start()

    def data_received(self, chunk):
        for target in self.targets:
            target.data_received(chunk)

    def finish(self):
        for target in self.targets:
            target.finish()


class _Parser:
    def __init__(self, delimiter, ender, strict):
        self.delimiter_finder = Finder(delimiter)
        self.ender_finder = Finder(ender)

        self.delimiter_length = len(delimiter)
        self.ender_length = len(ender)

        self._state = ParserState.PS_START

        self.expected_parts = []
        self.active_part = None
        self.default_part = Part('_default', NullTarget())

        self._leftover_buffer = None

        self.strict = strict
        self.unexpected_part_name = ''

    def register(self, name, target):
        part = self._part_for(name)
        if part:
            part.add_target(target)
        else:
            self.expected_parts.append(Part(name, target))

    def _set_active_part(self, part, filename):
        self.active_part = part
        self.active_part.set_multipart_filename(filename)
        self.active_part.start()

    def _unset_active_part(self):
        if self.active_part:
            self.active_part.finish()
        self.active_part = None

    def _on_body(self, value):
        if self.active_part and len(value) > 0:
            self.active_part.data_received(value)

    def _part_for(self, name):
        for part in self.expected_parts:
            if part.name == name:
                return part
        return None

    def data_received(self, data):
        if not data:
            return 0

        if self._leftover_buffer is not None:
            chunk = self._leftover_buffer + data
            index = len(self._leftover_buffer)
            self._leftover_buffer = None
        else:
            chunk = data
            index = 0

        return self._parse(chunk, index)

    def _parse(self, chunk, index):
        chunk_len = len(chunk)
        buffer_start = 0
        idx = index

        while idx < chunk_len:
            byte = chunk[idx]

            if self._state == ParserState.PS_START:
                if byte == c_hyphen:
                    buffer_start = idx
                    self._state = ParserState.PS_STARTING_BOUNDARY
                elif byte == c_cr:
                    self._state = ParserState.PS_START_CR
                else:
                    self._mark_error()
                    return ErrorGroup.Delimiting + 1

            elif self._state == ParserState.PS_START_CR:
                if byte == c_lf:
                    self._state = ParserState.PS_START
                else:
                    self._mark_error()
                    return ErrorGroup.Delimiting + 4

            elif self._state == ParserState.PS_STARTING_BOUNDARY:
                if byte != c_hyphen:
                    self._mark_error()
                    return ErrorGroup.Delimiting + 2
                self._state = ParserState.PS_READING_BOUNDARY

            elif self._state == ParserState.PS_READING_BOUNDARY:
                if byte == c_cr:
                    self._state = ParserState.PS_ENDING_BOUNDARY

            elif self._state == ParserState.PS_ENDING_BOUNDARY:
                if byte != c_lf:
                    self._mark_error()
                    return ErrorGroup.Delimiting + 3
                if b'\r\n' + chunk[buffer_start: idx + 1] != self.delimiter_finder.target:
                    self._mark_error()
                    return ErrorGroup.Delimiting + 5
                buffer_start = idx + 1
                self._state = ParserState.PS_READING_HEADER

            elif self._state == ParserState.PS_READING_HEADER:
                if byte == c_cr:
                    self._state = ParserState.PS_ENDING_HEADER

            elif self._state == ParserState.PS_ENDING_HEADER:
                if byte != c_lf:
                    self._mark_error()
                    return ErrorGroup.PartHeaders + 1

                message = Parser(policy=HTTP).parsestr(
                    chunk[buffer_start: idx + 1].decode('utf-8')
                )

                if 'content-disposition' in message:
                    if message.get_content_disposition() != 'form-data':
                        self._mark_error()
                        return ErrorGroup.PartHeaders + 1
                    params = message['content-disposition'].params
                    name = params.get('name')
                    if name:
                        part = self._part_for(name)
                        if part is None:
                            part = self.default_part
                            if self.strict:
                                self.unexpected_part_name = name
                                self._mark_error()
                                return ErrorGroup.UnexpectedPart
                        self._set_active_part(part, params.get('filename'))
                elif 'content-type' in message:
                    if self.active_part:
                        self.active_part.set_multipart_content_type(
                            message.get_content_type()
                        )

                buffer_start = idx + 1
                self._state = ParserState.PS_ENDED_HEADER

            elif self._state == ParserState.PS_ENDED_HEADER:
                if byte == c_cr:
                    self._state = ParserState.PS_ENDING_ALL_HEADERS
                else:
                    self._state = ParserState.PS_READING_HEADER

            elif self._state == ParserState.PS_ENDING_ALL_HEADERS:
                if byte != c_lf:
                    self._mark_error()
                    return ErrorGroup.PartHeaders + 2
                buffer_start = idx + 1
                self._state = ParserState.PS_READING_BODY

            elif self._state == ParserState.PS_READING_BODY:
                self.delimiter_finder.feed(byte)
                self.ender_finder.feed(byte)

                if self.delimiter_finder.found():
                    self._state = ParserState.PS_READING_HEADER

                    if idx + 1 < self.delimiter_length:
                        self._mark_error()
                        return ErrorGroup.Internal + 1

                    match_start = idx + 1 - self.delimiter_length

                    if match_start >= buffer_start:
                        try:
                            self._on_body(chunk[buffer_start: match_start])
                        except Exception:
                            self._mark_error()
                            raise
                        buffer_start = idx + 1
                    else:
                        self._mark_error()
                        return ErrorGroup.Internal + 2

                    self._unset_active_part()
                    self.delimiter_finder._reset()

                elif self.ender_finder.found():
                    self._state = ParserState.PS_END

                    if idx + 1 < self.ender_length:
                        self._mark_error()
                        return ErrorGroup.Internal + 3

                    match_start = idx + 1 - self.ender_length

                    if match_start >= buffer_start:
                        try:
                            self._on_body(chunk[buffer_start: match_start])
                        except Exception:
                            self._mark_error()
                            raise
                    else:
                        self._mark_error()
                        return ErrorGroup.Internal + 4

                    buffer_start = idx + 1
                    self._unset_active_part()
                    self.ender_finder._reset()

                else:
                    if self.delimiter_finder.inactive():
                        skip_count = self._rewind_fast_forward(
                            chunk, idx + 1, chunk_len - 1
                        )
                        idx += skip_count

            elif self._state == ParserState.PS_END:
                return 0

            else:
                self._mark_error()
                return ErrorGroup.Internal + 5

            idx += 1

        if idx != chunk_len:
            self._mark_error()
            return ErrorGroup.Internal + 6

        if buffer_start > chunk_len:
            self._mark_error()
            return ErrorGroup.Internal + 7

        if self._state == ParserState.PS_READING_BODY:
            matched_length = max(
                self.delimiter_finder._matched_length(),
                self.ender_finder._matched_length()
            )
            match_start = idx - matched_length

            if match_start >= buffer_start + c_min_file_body_chunk_size:
                try:
                    self._on_body(chunk[buffer_start: match_start])
                except Exception:
                    self._mark_error()
                    raise
                buffer_start = match_start

        if idx - buffer_start > 0:
            self._leftover_buffer = chunk[buffer_start: idx]

        return 0

    def _rewind_fast_forward(self, chunk, pos_first, pos_last):
        if pos_first + 3 > pos_last:
            return 0

        ptr = pos_first + 3
        ptr_end = pos_last + 1
        skipped = 0

        while True:
            if ptr >= ptr_end:
                ptr = ptr_end - 1
                skipped = pos_last - pos_first + 1

                if chunk[ptr] == c_cr:
                    skipped = skipped - 1
                elif chunk[ptr] == c_lf and chunk[ptr - 1] == c_cr:
                    skipped = skipped - 2
                elif (
                    chunk[ptr] == c_hyphen
                    and chunk[ptr - 1] == c_lf
                    and chunk[ptr - 2] == c_cr
                ):
                    skipped = skipped - 3
                break

            if chunk[ptr] != c_hyphen:
                ptr += 2
            else:
                if chunk[ptr - 1] != c_hyphen:
                    ptr += 1
                else:
                    if chunk[ptr - 2] == c_lf and chunk[ptr - 3] == c_cr:
                        self.delimiter_finder._reset()
                        self.delimiter_finder.feed(c_cr)
                        self.delimiter_finder.feed(c_lf)
                        self.delimiter_finder.feed(c_hyphen)
                        self.delimiter_finder.feed(c_hyphen)

                        self.ender_finder._reset()
                        self.ender_finder.feed(c_cr)
                        self.ender_finder.feed(c_lf)
                        self.ender_finder.feed(c_hyphen)
                        self.ender_finder.feed(c_hyphen)

                        skipped = ptr - pos_first + 1
                        break
                    ptr += 4

        return skipped

    def _mark_error(self):
        self._state = ParserState.PS_ERROR
        if self.active_part:
            self.active_part.finish()
